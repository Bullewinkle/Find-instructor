var lodash = require('lodash');
var config = require('./config');
var express = require('express');
var mongoose = require('mongoose');


var app = express();


app.use(express.json());
app.use(express.urlencoded());
app.use(express.methodOverride());
app.use(express.static('./client'));


var userSchema = new mongoose.Schema({
	level: {
		type: Number,
		default: 1
	},
	name: {
		type: String,
		unique: true,
		required: true
	},
	pass: {
		type: String,
		required: true
	}
});

userSchema.path('name').validate(function (val, res) {
	if (val === 'admin') {
		res(false);
	} else {
		res(true);
	};
});





var User = mongoose.model('User', userSchema);


app.post('/register', function (req, res) {

	var query = req.body.query;

	User.create(query, function (err, data) {

		if (err) {
			res.json({success: false, msg: 'DB error', err: err});
		};

		if (data) {
			res.json({success: true, data: data});
		};

	});
	
});


app.post('/getall', function (req, res) {

	var query = req.body.query;

	User.find(query, function (err, data) {

		if (err) {
			res.json({success: false, msg: 'DB error', err: err});
		};

		if (data) {
			res.json({success: true, data: data});
		};

	});
	
});






mongoose.connect(config.mongo.url, function (err) {
	if (err) throw err;
	app.listen(config.port);
});