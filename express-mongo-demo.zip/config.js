module.exports = {

	mongo: {
		url: 'mongodb://bullewinkle:085321@paulo.mongohq.com:10074/dimon_db'
	},

	port: 5777

}